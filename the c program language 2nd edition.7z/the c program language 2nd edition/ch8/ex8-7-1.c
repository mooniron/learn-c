/**************************************************************
* Name     :  ex8-7-1.c
* Author   :  Bronze Lee
* Version  :  0.1
* Date     :  2017年4月5日
**************************************************************/


/*
exercise 8-7:
    malloc accepts a size request without checking its plausibility; free believes that the block
it is asked to free contains a valid size field. improve these routines so they make more pains
with error checking.
*/


