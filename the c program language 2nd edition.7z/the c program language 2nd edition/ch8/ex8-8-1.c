/**************************************************************
* Name     :  ex8-8-1.c
* Author   :  Bronze Lee
* Version  :  0.1
* Date     :  2017年4月5日
**************************************************************/


/*
exercise 8-8:
    write a routine bfree(p, n) that will free any arbitrary block p of n characters into the
free list maintained by malloc and free. by using bfree, a user can add a static or external
array to the free list at any time.
*/


