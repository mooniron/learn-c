/**************************************************************
* Name     :  ex1-1.c
* Author   :  Bronze Lee
* Version  :  0.1
* Date     :  2017年2月13日
**************************************************************/

#include <stdio.h>

/*--------------- MAIN Code Module -----------------*/
main ()
{
    printf("hello,world\n");
    printf("hello,");
    printf("world");
    printf("\n");

}
