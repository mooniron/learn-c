/*  signal that a number was found  */
#define NUMBER '0'
int getop(char []);
void push(double);
double pop(void);
int getch(void);
void ungetch(int);
